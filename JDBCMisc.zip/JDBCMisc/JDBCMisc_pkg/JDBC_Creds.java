package JDBCMisc_pkg;

public interface JDBC_Creds {
	public final String url = "jdbc:postgresql://localhost/TestDB";
	public final String user = "postgres";
	public final String password = "adhithya";
}
